select seq from sqlite_sequence where name = '~a'
