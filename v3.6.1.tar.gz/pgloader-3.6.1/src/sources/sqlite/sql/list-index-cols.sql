PRAGMA index_info(`~a`)
