select sql from sqlite_master where name = '~a'
