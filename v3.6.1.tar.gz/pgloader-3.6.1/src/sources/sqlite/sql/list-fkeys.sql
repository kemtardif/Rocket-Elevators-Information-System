PRAGMA foreign_key_list(`~a`)
