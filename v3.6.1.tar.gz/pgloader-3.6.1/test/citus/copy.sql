\copy companies from 'companies.csv' with csv
\copy campaigns from 'campaigns.csv' with csv
-- \copy ads from 'ads.csv' with csv
-- \copy clicks from 'clicks.csv' with csv
-- \copy impressions from 'impressions.csv' with csv
